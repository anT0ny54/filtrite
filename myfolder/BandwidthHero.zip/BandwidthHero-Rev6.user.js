// ==UserScript==
// @name         Bandwidth Hero Proxy Rev 6
// @namespace    bandwidth-hero-proxy-2
// @version      6.0.0
// @description  Maximum image bandwidth savings with a safe Firefox/Fennec prehook, one-time proxy→original failover, preload/picture support, and low-overhead DOM processing.
// @match        *://*/*
// @run-at       document-start
// @inject-into  page
// @grant        none
// ==/UserScript==

(() => {
    'use strict';

    /* =========================
       Configuration
       ========================= */

    // REQUIRED: replace with your deployed bandwidth-hero-proxy2 endpoint.
    const PROXY_URL = 'https://YOUR-NETLIFY-SITE.netlify.app/api/index';

    const EXCLUDED_DOMAINS = [
        'youtube.com',
        'google.com',
        'googleapis.com',
        'facebook.com',
        'instagram.com'
    ];

    // Maximum-savings profile.
    const QUALITY = 40;
    const GRAYSCALE = 1;
    const JPEG = 0;
    const MAX_IMAGE_WIDTH = 1280;

    // HTML meta CSP only. HTTP response CSP headers are outside userscript control.
    const STRIP_META_CSP = true;

    const INTERCEPT_IMAGE_PRELOADS = true;
    const INTERCEPT_PICTURE_SOURCES = true;
    const INTERCEPT_INLINE_BACKGROUNDS = true;

    // Keep this list focused: every extra attribute increases mutation work.
    const IMAGE_ATTRIBUTES = [
        'src',
        'srcset',
        'data-src',
        'data-srcset',
        'data-lazy-src',
        'data-lazy-srcset',
        'data-original',
        'data-original-src',
        'data-lazy',
        'data-image',
        'data-image-src',
        'data-url'
    ];

    const SOURCE_ATTRIBUTES = [
        'src',
        'srcset',
        'data-src',
        'data-srcset',
        'data-lazy-src',
        'data-lazy-srcset'
    ];

    const OBSERVED_ATTRIBUTES = Array.from(new Set([
        ...IMAGE_ATTRIBUTES,
        'style',
        'http-equiv',
        'href',
        'rel',
        'as'
    ]));

    const MAX_PROXY_CACHE = 1200;
    const FAILOVER_STATE = Object.freeze({
        PROXY: 1,
        ORIGINAL: 2,
        DONE: 3,
        FAILED: 4
    });

    let proxyBase;
    try {
        proxyBase = new URL(PROXY_URL);
    } catch {
        console.error('[BandwidthHero Rev6] Invalid PROXY_URL:', PROXY_URL);
        return;
    }

    if (!/^https?:$/.test(proxyBase.protocol)) {
        console.error('[BandwidthHero Rev6] PROXY_URL must use HTTP(S):', PROXY_URL);
        return;
    }

    const normalizeDomain = value => String(value || '')
        .toLowerCase()
        .trim()
        .replace(/^https?:\/\//, '')
        .replace(/^www\./, '')
        .split('/')[0]
        .split(':')[0];

    const excludedDomains = new Set(EXCLUDED_DOMAINS.map(normalizeDomain));

    function isExcludedDomain(hostname) {
        const host = normalizeDomain(hostname);
        for (const domain of excludedDomains) {
            if (host === domain || host.endsWith(`.${domain}`)) return true;
        }
        return false;
    }

    if (isExcludedDomain(location.hostname)) return;

    /* =========================
       URL handling + bounded LRU cache
       ========================= */

    const proxyCache = new Map();

    function rememberProxy(key, value) {
        if (proxyCache.has(key)) proxyCache.delete(key);
        proxyCache.set(key, value);
        while (proxyCache.size > MAX_PROXY_CACHE) {
            proxyCache.delete(proxyCache.keys().next().value);
        }
        return value;
    }

    function absoluteURL(value) {
        if (!value) return null;
        try {
            return new URL(value, document.baseURI || location.href).href;
        } catch {
            return null;
        }
    }

    function isSkippableURL(value) {
        const text = String(value || '').trim();
        if (!text || text.startsWith('#')) return true;
        return /^(?:data|blob|javascript|about):/i.test(text);
    }

    function isProxyURL(value) {
        const absolute = absoluteURL(value);
        if (!absolute) return false;
        try {
            const url = new URL(absolute);
            return url.origin === proxyBase.origin && url.pathname === proxyBase.pathname;
        } catch {
            return false;
        }
    }

    function shouldProxyURL(value) {
        if (isSkippableURL(value)) return false;
        const absolute = absoluteURL(value);
        if (!absolute) return false;

        try {
            const url = new URL(absolute);
            if (!/^https?:$/.test(url.protocol)) return false;
            if (isProxyURL(url.href)) return false;
            if (isExcludedDomain(url.hostname)) return false;
            return true;
        } catch {
            return false;
        }
    }

    function getProxyURL(value) {
        if (!shouldProxyURL(value)) return null;
        const absolute = absoluteURL(value);
        if (!absolute) return null;

        const cached = proxyCache.get(absolute);
        if (cached) {
            proxyCache.delete(absolute);
            proxyCache.set(absolute, cached);
            return cached;
        }

        try {
            const proxy = new URL(proxyBase.href);
            proxy.searchParams.set('url', absolute);
            proxy.searchParams.set('quality', String(QUALITY));
            proxy.searchParams.set('l', String(QUALITY));
            proxy.searchParams.set('bw', String(GRAYSCALE ? 1 : 0));
            proxy.searchParams.set('jpeg', String(JPEG ? 1 : 0));
            proxy.searchParams.set('max_width', String(Math.max(0, Math.floor(MAX_IMAGE_WIDTH))));
            return rememberProxy(absolute, proxy.href);
        } catch {
            return null;
        }
    }

    function rewriteSrcset(value) {
        if (!value) return value;
        const originalValue = String(value);
        let changed = false;

        const result = originalValue.split(',').map(candidate => {
            const leading = candidate.match(/^\s*/)?.[0] || '';
            const trailing = candidate.match(/\s*$/)?.[0] || '';
            const body = candidate.slice(leading.length, candidate.length - trailing.length || candidate.length);
            if (!body) return candidate;

            const match = body.match(/^(\S+)([\s\S]*)$/);
            if (!match) return candidate;

            const originalURL = match[1];
            const proxy = getProxyURL(originalURL);
            if (!proxy) return candidate;

            changed = true;
            return `${leading}${proxy}${match[2]}${trailing}`;
        }).join(',');

        return changed ? result : originalValue;
    }

    function rewriteCSSURLs(value) {
        if (!value || value === 'none') return value;
        return String(value).replace(
            /url\(\s*(['"]?)(.*?)\1\s*\)/gi,
            (match, quote, original) => {
                const proxy = getProxyURL(original);
                return proxy ? `url("${proxy}")` : match;
            }
        );
    }

    /* =========================
       Native references
       ========================= */

    const nativeImageSrc = Object.getOwnPropertyDescriptor(HTMLImageElement.prototype, 'src');
    const nativeImageSrcset = Object.getOwnPropertyDescriptor(HTMLImageElement.prototype, 'srcset');
    const nativeSourceSrc = Object.getOwnPropertyDescriptor(HTMLSourceElement.prototype, 'src');
    const nativeSourceSrcset = Object.getOwnPropertyDescriptor(HTMLSourceElement.prototype, 'srcset');
    const nativeLinkHref = Object.getOwnPropertyDescriptor(HTMLLinkElement.prototype, 'href');
    const nativeSetAttribute = Element.prototype.setAttribute;
    const nativeRemoveAttribute = Element.prototype.removeAttribute;
    const NativeImage = window.Image;

    // Per-element state never leaks into page markup and is GC-friendly.
    const imageStates = new WeakMap();
    const sourceOriginals = new WeakMap();
    const preloadOriginals = new WeakMap();
    const hookedImages = new WeakSet();
    const hookedLinks = new WeakSet();

    function getImageState(image) {
        let state = imageStates.get(image);
        if (!state) {
            state = {
                state: FAILOVER_STATE.PROXY,
                original: new Map(),
                proxy: new Map(),
                failoverUsed: false,
                handlerInstalled: false
            };
            imageStates.set(image, state);
        }
        return state;
    }

    function snapshotOriginal(state, name, value) {
        if (value == null || value === '') return;
        if (!state.original.has(name)) state.original.set(name, String(value));
    }

    function safeSetAttribute(element, name, value) {
        try {
            nativeSetAttribute.call(element, name, value);
        } catch {}
    }

    function safeRemoveAttribute(element, name) {
        try {
            nativeRemoveAttribute.call(element, name);
        } catch {}
    }

    function rewriteAttributeValue(name, value) {
        if (value == null) return value;
        const attr = String(name).toLowerCase();
        if (attr.includes('srcset')) return rewriteSrcset(String(value));
        return getProxyURL(String(value)) || value;
    }

    function isImagePreload(link) {
        if (!INTERCEPT_IMAGE_PRELOADS || !(link instanceof HTMLLinkElement)) return false;
        const rel = (link.getAttribute('rel') || '').toLowerCase().split(/\s+/);
        const as = (link.getAttribute('as') || '').toLowerCase();
        return rel.includes('preload') && as === 'image';
    }

    /* =========================
       One-time image failover
       ========================= */

    function installImageErrorHandler(image) {
        const state = getImageState(image);
        if (state.handlerInstalled) return;
        state.handlerInstalled = true;

        image.addEventListener('error', () => {
            const current = getImageState(image);
            if (current.failoverUsed || current.state === FAILOVER_STATE.FAILED) return;

            // Only fail over when the current resource was actually proxied.
            let hasProxyResource = false;
            for (const value of current.proxy.values()) {
                if (value && isProxyURL(value)) {
                    hasProxyResource = true;
                    break;
                }
            }
            if (!hasProxyResource) return;

            current.failoverUsed = true;
            current.state = FAILOVER_STATE.ORIGINAL;

            // Native setters bypass the prehook and therefore cannot accidentally re-proxy.
            for (const [name, original] of current.original) {
                safeSetAttribute(image, name, original);
            }

            // If the original src attribute did not exist but the hook stored a property URL,
            // restore it natively as a last resort.
            const originalSrc = current.original.get('src');
            if (originalSrc) {
                try { nativeImageSrc?.set?.call(image, originalSrc); } catch {}
            }

            current.proxy.clear();

            // Give the original resource exactly one chance.
            const verify = () => {
                current.state = image.complete && image.naturalWidth > 0
                    ? FAILOVER_STATE.DONE
                    : FAILOVER_STATE.ORIGINAL;
            };
            image.addEventListener('load', verify, { once: true });
        }, { passive: true });
    }

    function prepareImage(image) {
        if (!(image instanceof HTMLImageElement)) return getImageState(image);
        installImageErrorHandler(image);
        return getImageState(image);
    }

    function proxyImageAttribute(image, attr, value) {
        if (!value) return;
        const state = prepareImage(image);

        // Never rewrite again after the one-time original fallback.
        if (state.failoverUsed) return;

        const text = String(value);
        const rewritten = rewriteAttributeValue(attr, text);
        if (rewritten === text) return;

        snapshotOriginal(state, attr, text);
        state.proxy.set(attr, rewritten);
        nativeSetAttribute.call(image, attr, rewritten);
        state.state = FAILOVER_STATE.PROXY;
    }

    function proxyImage(image) {
        if (!(image instanceof HTMLImageElement)) return;
        const state = prepareImage(image);
        if (state.failoverUsed) return;

        for (const attr of IMAGE_ATTRIBUTES) {
            const value = image.getAttribute(attr);
            if (value) proxyImageAttribute(image, attr, value);
        }

        // Ensure an image that already has a resolved src but no src attribute is handled.
        const current = image.getAttribute('src') || image.currentSrc || '';
        if (current && !isProxyURL(current)) {
            const proxy = getProxyURL(current);
            if (proxy && proxy !== current) {
                snapshotOriginal(state, 'src', current);
                state.proxy.set('src', proxy);
                try { nativeImageSrc?.set?.call(image, proxy); } catch {}
                state.state = FAILOVER_STATE.PROXY;
            }
        }
    }

    /* =========================
       Preload handling
       ========================= */

    function rewritePreload(link) {
        if (!isImagePreload(link)) return;
        const href = link.getAttribute('href');
        if (!href || isProxyURL(href)) return;

        const proxy = getProxyURL(href);
        if (!proxy || proxy === href) return;

        if (!preloadOriginals.has(link)) preloadOriginals.set(link, href);
        safeSetAttribute(link, 'href', proxy);

        if (!hookedLinks.has(link)) {
            hookedLinks.add(link);
            link.addEventListener('error', () => {
                const original = preloadOriginals.get(link);
                if (original) safeSetAttribute(link, 'href', original);
            }, { once: true, passive: true });
        }
    }

    function maybeRewritePreload(link) {
        if (isImagePreload(link)) rewritePreload(link);
    }

    /* =========================
       Safe early prehook
       ========================= */

    function installPrehook() {
        if (nativeImageSrc?.get && nativeImageSrc?.set) {
            try {
                Object.defineProperty(HTMLImageElement.prototype, 'src', {
                    configurable: nativeImageSrc.configurable,
                    enumerable: nativeImageSrc.enumerable,
                    get: nativeImageSrc.get,
                    set(value) {
                        const original = String(value);
                        const state = prepareImage(this);
                        if (state.failoverUsed) {
                            return nativeImageSrc.set.call(this, value);
                        }

                        const proxy = getProxyURL(original);
                        if (proxy && proxy !== original) {
                            snapshotOriginal(state, 'src', original);
                            state.proxy.set('src', proxy);
                            state.state = FAILOVER_STATE.PROXY;
                            return nativeImageSrc.set.call(this, proxy);
                        }
                        return nativeImageSrc.set.call(this, value);
                    }
                });
            } catch (e) {
                console.warn('[BandwidthHero Rev6] src hook failed:', e);
            }
        }

        if (nativeImageSrcset?.get && nativeImageSrcset?.set) {
            try {
                Object.defineProperty(HTMLImageElement.prototype, 'srcset', {
                    configurable: nativeImageSrcset.configurable,
                    enumerable: nativeImageSrcset.enumerable,
                    get: nativeImageSrcset.get,
                    set(value) {
                        const original = String(value);
                        const state = prepareImage(this);
                        if (state.failoverUsed) return nativeImageSrcset.set.call(this, value);

                        const rewritten = rewriteSrcset(original);
                        if (rewritten !== original) {
                            snapshotOriginal(state, 'srcset', original);
                            state.proxy.set('srcset', rewritten);
                            state.state = FAILOVER_STATE.PROXY;
                        }
                        return nativeImageSrcset.set.call(this, rewritten);
                    }
                });
            } catch (e) {
                console.warn('[BandwidthHero Rev6] srcset hook failed:', e);
            }
        }

        if (INTERCEPT_PICTURE_SOURCES && nativeSourceSrc?.get && nativeSourceSrc?.set) {
            try {
                Object.defineProperty(HTMLSourceElement.prototype, 'src', {
                    configurable: nativeSourceSrc.configurable,
                    enumerable: nativeSourceSrc.enumerable,
                    get: nativeSourceSrc.get,
                    set(value) {
                        const original = String(value);
                        const proxy = getProxyURL(original);
                        if (proxy && proxy !== original) {
                            sourceOriginals.set(this, original);
                            return nativeSourceSrc.set.call(this, proxy);
                        }
                        return nativeSourceSrc.set.call(this, value);
                    }
                });
            } catch (e) {
                console.warn('[BandwidthHero Rev6] source.src hook failed:', e);
            }
        }

        if (INTERCEPT_PICTURE_SOURCES && nativeSourceSrcset?.get && nativeSourceSrcset?.set) {
            try {
                Object.defineProperty(HTMLSourceElement.prototype, 'srcset', {
                    configurable: nativeSourceSrcset.configurable,
                    enumerable: nativeSourceSrcset.enumerable,
                    get: nativeSourceSrcset.get,
                    set(value) {
                        const original = String(value);
                        const rewritten = rewriteSrcset(original);
                        if (rewritten !== original) sourceOriginals.set(this, original);
                        return nativeSourceSrcset.set.call(this, rewritten);
                    }
                });
            } catch (e) {
                console.warn('[BandwidthHero Rev6] source.srcset hook failed:', e);
            }
        }

        try {
            Element.prototype.setAttribute = function(name, value) {
                const attr = String(name).toLowerCase();

                if (this instanceof HTMLImageElement && IMAGE_ATTRIBUTES.includes(attr)) {
                    const state = prepareImage(this);
                    if (state.failoverUsed) return nativeSetAttribute.call(this, name, value);

                    const original = String(value);
                    const rewritten = rewriteAttributeValue(attr, original);
                    if (rewritten !== original) {
                        snapshotOriginal(state, attr, original);
                        state.proxy.set(attr, rewritten);
                        state.state = FAILOVER_STATE.PROXY;
                    }
                    return nativeSetAttribute.call(this, name, rewritten);
                }

                if (INTERCEPT_PICTURE_SOURCES && this instanceof HTMLSourceElement && SOURCE_ATTRIBUTES.includes(attr)) {
                    const original = String(value);
                    const rewritten = rewriteAttributeValue(attr, original);
                    if (rewritten !== original) sourceOriginals.set(this, original);
                    return nativeSetAttribute.call(this, name, rewritten);
                }

                if (INTERCEPT_IMAGE_PRELOADS && this instanceof HTMLLinkElement) {
                    if (attr === 'href') {
                        const original = String(value);
                        if (isImagePreload(this)) {
                            const proxy = getProxyURL(original);
                            if (proxy && proxy !== original) {
                                if (!preloadOriginals.has(this)) preloadOriginals.set(this, original);
                                return nativeSetAttribute.call(this, name, proxy);
                            }
                        }
                    }

                    const result = nativeSetAttribute.call(this, name, value);
                    if (attr === 'rel' || attr === 'as' || attr === 'href') maybeRewritePreload(this);
                    return result;
                }

                return nativeSetAttribute.call(this, name, value);
            };
        } catch (e) {
            console.warn('[BandwidthHero Rev6] setAttribute hook failed:', e);
        }

        // Preserve Image() constructor behavior while ensuring its returned element
        // uses the already-installed prototype hooks. No custom loading behavior is added.
        if (typeof NativeImage === 'function') {
            try {
                const WrappedImage = function(width, height) {
                    return arguments.length ? new NativeImage(width, height) : new NativeImage();
                };
                WrappedImage.prototype = NativeImage.prototype;
                Object.setPrototypeOf(WrappedImage, NativeImage);
                window.Image = WrappedImage;
            } catch (e) {
                console.warn('[BandwidthHero Rev6] Image() hook failed:', e);
            }
        }
    }

    /* =========================
       Other resource processing
       ========================= */

    function proxySource(source) {
        if (!(source instanceof HTMLSourceElement) || !INTERCEPT_PICTURE_SOURCES) return;
        for (const attr of SOURCE_ATTRIBUTES) {
            const value = source.getAttribute(attr);
            if (!value) continue;
            const rewritten = rewriteAttributeValue(attr, value);
            if (rewritten !== value) {
                sourceOriginals.set(source, sourceOriginals.get(source) || value);
                safeSetAttribute(source, attr, rewritten);
            }
        }
    }

    function proxyInputImage(input) {
        if (!(input instanceof HTMLInputElement) || input.type !== 'image') return;
        const value = input.getAttribute('src');
        if (!value || isProxyURL(value)) return;
        const proxy = getProxyURL(value);
        if (proxy && proxy !== value) safeSetAttribute(input, 'src', proxy);
    }

    function proxyInlineBackground(element) {
        if (!INTERCEPT_INLINE_BACKGROUNDS || !(element instanceof HTMLElement)) return;
        const style = element.getAttribute('style');
        if (!style || !/background(?:-image)?\s*:/i.test(style)) return;
        const rewritten = rewriteCSSURLs(style);
        if (rewritten !== style) safeSetAttribute(element, 'style', rewritten);
    }

    function isCSPMeta(element) {
        if (!(element instanceof HTMLMetaElement)) return false;
        const httpEquiv = (element.getAttribute('http-equiv') || '').toLowerCase();
        const name = (element.getAttribute('name') || '').toLowerCase();
        return httpEquiv === 'content-security-policy' || name === 'content-security-policy';
    }

    function stripCSPMeta(root = document) {
        if (!STRIP_META_CSP || !root) return;
        if (isCSPMeta(root)) {
            root.remove();
            return;
        }
        if (!root.querySelectorAll) return;
        for (const meta of root.querySelectorAll('meta[http-equiv],meta[name]')) {
            if (isCSPMeta(meta)) meta.remove();
        }
    }

    function processElement(element, deep = true) {
        if (!(element instanceof Element)) return;

        if (isCSPMeta(element)) {
            element.remove();
            return;
        }

        if (element instanceof HTMLImageElement) proxyImage(element);
        else if (element instanceof HTMLSourceElement) proxySource(element);
        else if (element instanceof HTMLInputElement) proxyInputImage(element);
        else if (element instanceof HTMLLinkElement) rewritePreload(element);
        if (element instanceof HTMLElement) proxyInlineBackground(element);

        if (!deep || !element.querySelectorAll) return;

        // Targeted descendant scans only. No repeated full-document scans here.
        for (const image of element.querySelectorAll('img')) proxyImage(image);
        if (INTERCEPT_PICTURE_SOURCES) {
            for (const source of element.querySelectorAll('source')) proxySource(source);
        }
        for (const input of element.querySelectorAll('input[type="image"]')) proxyInputImage(input);
        if (INTERCEPT_INLINE_BACKGROUNDS) {
            for (const styled of element.querySelectorAll('[style]')) proxyInlineBackground(styled);
        }
        if (INTERCEPT_IMAGE_PRELOADS) {
            for (const link of element.querySelectorAll('link[rel~="preload"][as="image"]')) rewritePreload(link);
        }
    }

    function processPage() {
        stripCSPMeta();
        for (const image of document.images) proxyImage(image);
        if (INTERCEPT_PICTURE_SOURCES) for (const source of document.querySelectorAll('source')) proxySource(source);
        for (const input of document.querySelectorAll('input[type="image"]')) proxyInputImage(input);
        if (INTERCEPT_INLINE_BACKGROUNDS) for (const styled of document.querySelectorAll('[style]')) proxyInlineBackground(styled);
        if (INTERCEPT_IMAGE_PRELOADS) for (const link of document.querySelectorAll('link[rel~="preload"][as="image"]')) rewritePreload(link);
    }

    /* =========================
       Low-overhead mutation batching
       ========================= */

    const pending = new Set();
    let timer = 0;

    function scheduleElement(element, deep = true) {
        if (!(element instanceof Element)) return;
        pending.add(element);

        if (timer) return;
        timer = setTimeout(() => {
            timer = 0;
            const batch = Array.from(pending);
            pending.clear();
            for (const node of batch) {
                if (node.isConnected) processElement(node, deep);
            }
        }, 32);
    }

    function startObserver() {
        const observer = new MutationObserver(mutations => {
            for (const mutation of mutations) {
                if (mutation.type === 'childList') {
                    for (const node of mutation.addedNodes) {
                        if (!(node instanceof Element)) continue;

                        // Small leaf nodes are cheap to process directly; containers need a scan.
                        const deep = node.children.length > 0 || node.childElementCount > 0;
                        scheduleElement(node, deep);
                    }
                } else if (mutation.type === 'attributes') {
                    const target = mutation.target;
                    if (mutation.attributeName === 'http-equiv' && isCSPMeta(target)) {
                        target.remove();
                    } else if (target instanceof HTMLImageElement ||
                               target instanceof HTMLSourceElement ||
                               target instanceof HTMLLinkElement ||
                               target instanceof HTMLInputElement ||
                               (target instanceof HTMLElement && mutation.attributeName === 'style')) {
                        scheduleElement(target, false);
                    }
                }
            }
        });

        const root = document.documentElement || document;
        observer.observe(root, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: OBSERVED_ATTRIBUTES
        });
    }

    /* =========================
       Startup
       ========================= */

    function start() {
        installPrehook();
        stripCSPMeta();
        startObserver();
        processPage();

        // One delayed pass for frameworks/lazy loaders; normal changes are handled by the observer.
        setTimeout(processPage, 1500);
    }

    start();
})();
