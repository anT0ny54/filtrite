Bandwidth Hero Proxy Rev 6
==========================

Goal
----
Maximum image bandwidth savings while remaining conservative with Firefox/Fennec
page semantics and minimizing CPU overhead.

Main changes
------------
- Safe document-start/page-context prehook for HTMLImageElement.src/srcset.
- Safe <picture>/<source> src/srcset interception.
- setAttribute interception for image/lazy attributes.
- Image() compatibility wrapper; native image semantics remain intact.
- Image preload interception: <link rel="preload" as="image">.
- One-time sequential failover: proxy -> original -> stop.
- Failover bypasses the prehook, so the original URL cannot be accidentally re-proxied.
- Per-element WeakMap state instead of data-* state attributes.
- Bounded LRU proxy URL cache (1200 entries) for lower mobile memory use.
- Targeted MutationObserver processing with one delayed page pass instead of repeated
  full-page rescans.
- srcset descriptors are preserved.
- loading/fetchpriority/decoding/crossorigin/referrerpolicy are not modified.
- Optional inline CSS background-image URL rewriting.
- HTML meta CSP removal only; HTTP response CSP headers are not claimed to be bypassed.
- No blank-image pixel/canvas detection by default: avoids CPU, memory, CORS and timing costs.

Important
---------
Replace PROXY_URL before use.

DNS/privacy note
----------------
A userscript can minimize direct origin image requests, but cannot guarantee that a
browser never performs speculative DNS/network work for an origin. Server-side DNS
rebinding/SSRF protections remain required.

Compatibility target
--------------------
Violentmonkey/Tampermonkey on Firefox/Fennec and Chromium-family browsers.
The script uses native property descriptors and native setAttribute calls to reduce
monkey-patching recursion and preserve page semantics.
